//
//  HPMigrationPlan.swift
//  HuliPizzaPersistent
//
//  Created by Steven Lipton on 2/13/24.
//

import Foundation
import SwiftData

enum HPMigrationPlan: SchemaMigrationPlan{
    static var schemas: [VersionedSchema.Type]{
        [HPSchemaV01_00_00.self]
    }
    
    static var stages: [MigrationStage]{
        []
    }
    
    
}
